# Postman Collection per Series

Referensi belajar untuk blog ABAP Nusantara. Setiap series punya sepasang file yang berdiri sendiri:

| Series | Collection | Environment | Request CPI / mock |
| --- | --- | --- | --- |
| 1. Fondasi | `tkn-series-1.postman_collection.json` | `tkn-series-1.postman_environment.json` | 3 / 14 |
| 2. Konektivitas dan Keamanan | `tkn-series-2.postman_collection.json` | `tkn-series-2.postman_environment.json` | 9 / 6 |
| 3. Pola Integrasi | `tkn-series-3.postman_collection.json` | `tkn-series-3.postman_environment.json` | 10 / 17 |
| 4. Mapping dan Transformasi | `tkn-series-4.postman_collection.json` | `tkn-series-4.postman_environment.json` | 6 / 8 |

Series 5 menyusul.

## Isi tiap collection

1. **Panggil iFlow (CPI)**: Postman sebagai ERP yang memanggil iFlow buatanmu. OAuth 2.0 client credentials sudah dipasang di folder ini. Request baru hijau setelah iFlow-nya kamu bangun mengikuti artikel.
2. **API tiruan (mock)**: request dengan saved example. Dari sini kamu membuat Mock Server (artikel S1-7).

## Cara pakai

1. Import collection dan environment (File → Import), lalu pilih environment-nya di pojok kanan atas.
2. **Mock:** klik kanan collection → *Mock collection*, pilih environment tadi. Salin URL mock (`https://<id>.mock.pstmn.io`) ke variabel `baseUrl`.
3. **CPI:** isi `cpiUrl`, `cpiTokenUrl`, `cpiClientId`, `cpiClientSecret` dari service key tenant kamu (artikel S1-2). Buka tab *Authorization* folder *Panggil iFlow (CPI)* → *Get New Access Token* → *Use Token*.
4. Kirim request, atau *Run folder* untuk menjalankan semuanya.

Semua nilai di file ini placeholder atau data demo (`tkn-demo-client` dan `tkn-demo-secret` hanya dikenali mock, yang tidak memeriksanya). Jangan menulis credential tenant asli ke file yang kamu bagikan.

## Catatan

- Tes mengikuti **keadaan akhir** series. Beberapa baru hijau setelah artikel tertentu; deskripsi request menyebutnya (misalnya hasil 404 dan 422 di Series 2 baru benar setelah S2-8).
- Mock server membalas example yang paling mirip, bukan 404, untuk path yang tidak terdaftar. Panggil hanya path yang ada di collection (S1-7).
- Panggilan pertama ke mock yang lama diam bisa memakan belasan detik (cold start).
- Series 4: *Sales order - ditemukan* baru hijau setelah S4-4 (balasan format ERP); tes `erpReasonCode` setelah S4-5. Mock perlu v0.3 (`POST /payments/limit`).
- Series 3: jalankan *Batch - campuran* sebelum *Payment - tersimpan dari batch* dan *Payment - masih menunggu*.
- Sumber: `../toko-nusantara-mock/build_series_collections.py`. Ubah di sana, jangan edit JSON-nya.
