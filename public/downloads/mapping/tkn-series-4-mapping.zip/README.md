# File mapping Series 4

Pendamping artikel Series 4 blog ABAP Nusantara (Mapping dan Transformasi Data). Semua data fiktif.

| File | Dipakai di |
| --- | --- |
| `CanonicalOrder.xsd` | Format kanonik order (S4-2); source Message Mapping (S4-3) |
| `ErpSalesOrder.wsdl` | Layanan sales order ERP fiktif; target Message Mapping, message `SalesOrderCreateRequest` (S4-3) |
| `contoh-CanonicalOrder.xml` | Contoh XML kanonik untuk Simulate (S4-3, S4-4) |
| `contoh-SalesOrderCreateRequest.xml` | Hasil mapping yang diharapkan untuk contoh di atas |

Kedua contoh XML lolos validasi terhadap XSD/WSDL-nya (`xmllint --schema`).
